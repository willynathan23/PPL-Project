<br>
<div class="row text-end">
    <div class="col-4">
        <a href="?ahref=jadwal" style="text-decoration: none; color: black;">
            <div class="card" style="width: 18rem;">
                <img src="/img/view-admin/foto3.jpg" class="card-img-top" alt="foto 3">
                <div class="card-body">
                    <h5 class="card-title">Jadwal</h5>
                </div>
            </div>
        </a>
    </div>

    <div class="col-4">
        <a href="?ahref=matakuliah" style="text-decoration: none; color: black;">
            <div class="card" style="width: 18rem;">
                <img src="/img/view-admin//foto5.jpg" class="card-img-top" alt="foto 5">
                <div class="card-body">
                    <h5 class="card-title">Mata Kuliah</h5>
                </div>
            </div>
        </a>
    </div>

    <div class="col-4">
        <a href="?ahref=dosen" style="text-decoration: none; color: black;">
            <div class="card" style="width: 18rem;">
                <img src="/img/view-admin/foto2.jpg" class="card-img-top" alt="foto 2">
                <div class="card-body">
                    <h5 class="card-title">Dosen</h5>
                </div>
            </div>
        </a>
    </div>
</div>

<br>

<div class="row text-end mb-5">
    <div class="col-4">
        <a href="?ahref=ruangan" style="text-decoration: none; color: black;">
            <div class="card" style="width: 18rem;">
                <img src="/img/view-admin/foto1.jpg" class="card-img-top" alt="foto 1">
                <div class="card-body">
                    <h5 class="card-title">Ruangan</h5>
                </div>
            </div>
        </a>
    </div>

    <div class="col-4">
        <a href="?ahref=mahasiswa" style="text-decoration: none; color: black;">
            <div class="card" style="width: 18rem;">
                <img src="/img/view-admin/foto4.jpg" class="card-img-top" alt="foto 4">
                <div class="card-body">
                    <h5 class="card-title">Mahasiswa</h5>
                </div>
            </div>
        </a>
    </div>

    <div class="col-4">
        <a href="?ahref=semester" style="text-decoration: none; color: black;">
            <div class="card" style="width: 18rem;">
                <img src="/img/view-admin/foto6.jpeg" class="card-img-top" alt="foto 6">
                <div class="card-body">
                    <h5 class="card-title">Semester</h5>
                </div>
            </div>
        </a>
    </div>
</div>

<br>

<table class="display" id="abs">
    <thead>
        <tr style="background-color: #89FF41;">
            <th>NIK</th>
            <th>Dosen</th>
            <th>Mata Kuliah</th>
            <th>Kelas</th>
            <th>Ruangan</th>
            <!-- jumlah pertemuan, tgl, waktu mulai-selesai -->
            <th>(Pertemuan) Waktu</th> 
            <th>Semester</th>
        </tr>
    </thead>
    <tbody>
        <!-- <?php
        /**@var $item Jadwal */

        foreach ($jad as $item) {

            echo '<tr>';
            echo '<td>' . $item->getMatkul()->getNamaM() . '</td>';
            echo '<td>' . $item->getKelas() . '</td>';
            echo '<td>' . $item->getRuangan()->getNamaR() . '</td>';
            echo '<td>' . $item->getTipe() . '</td>';
            echo '<td>' . $item->getSemester()->getPeriode() . '</td>';
            echo '</tr>';
        }
        ?> -->
    </tbody>

    <script>
        $(document).ready(function() {
            $("#abs").DataTable();
        });
    </script>
</table>
